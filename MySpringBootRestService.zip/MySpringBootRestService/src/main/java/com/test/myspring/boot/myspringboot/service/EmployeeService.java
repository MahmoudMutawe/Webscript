package com.test.myspring.boot.myspringboot.service;

import java.util.List;

import com.test.myspring.boot.myspringboot.EmployeeRepository;
import com.test.myspring.boot.myspringboot.bean.Employee;

public class EmployeeService {
		 
	    private EmployeeRepository employeeRepository;
	 
	    public EmployeeService(EmployeeRepository employeeRepository) {
	        this.employeeRepository = employeeRepository;
	    }
	 
	    public Iterable<Employee> list() {
	        return employeeRepository.findAll();
	    }
	 
	    public Iterable<Employee> save(List<Employee> users) {
	        return employeeRepository.save(users);
	    }
	 
}
