package com.test.myspring.boot.myspringboot.controller;

import com.test.myspring.boot.myspringboot.bean.Employee;
import com.test.myspring.boot.myspringboot.service.EmployeeService;

@RequestMapping("/employees")
public class EmployeeController {

	    private EmployeeService employeeService;
	 
	    public EmployeeController(EmployeeService employeeService) {
	        this.employeeService = employeeService;
	    }
	 
	    @GetMapping("/list")
	    public Iterable<Employee> list() {
	        return employeeService.list();
	    }
}
