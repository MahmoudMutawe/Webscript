package com.test.myspring.boot.myspringboot;

import com.test.myspring.boot.myspringboot.bean.Employee;
import org.springframework.data.repository.CrudRepository;

public interface EmployeeRepository extends CrudRepository<Employee, Long> {



}

