package com.test.myspring.boot.myspringboot.util;

public enum Department {
	
	HR("Human Resource"),
	IT("Information Technology"),
	OTH("Others");
	
	private final String deptName;
	
	private Department(String deptName) {
		this.deptName = deptName;
	}

}
